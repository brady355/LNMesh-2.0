export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
date -u --iso-8601=seconds
systemctl restart lnmesh-mesh
systemctl --no-pager --full status lnmesh-mesh
iw dev wlan0 link
ping -I bat0 -c 3 -W 2 10.10.0.2 &
ping -I bat0 -c 3 -W 2 10.10.0.3 &
wait
batctl meshif bat0 neighbors
batctl meshif bat0 originators
