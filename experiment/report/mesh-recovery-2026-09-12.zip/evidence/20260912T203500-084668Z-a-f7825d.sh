export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
set -euo pipefail
date -u --iso-8601=seconds
systemctl stop lnmesh-mesh-health.timer
trap 'systemctl start lnmesh-mesh-health.timer' EXIT
before=$(systemctl show lnmesh-mesh -p InvocationID --value)
printf '0\n' > /run/lnmesh-mesh-health.failures
for attempt in 1 2 3; do
  systemctl start lnmesh-mesh-health.service
done
for attempt in $(seq 1 25); do
  after=$(systemctl show lnmesh-mesh -p InvocationID --value)
  if test "$after" != "$before" && systemctl is-active --quiet lnmesh-mesh; then break; fi
  sleep 1
done
printf 'Mesh invocation before: %s\nMesh invocation after: %s\n' "$before" "$after"
systemctl --no-pager --full status lnmesh-mesh
journalctl -u lnmesh-mesh-health --since '3 minutes ago' --no-pager
batctl meshif bat0 neighbors
