export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
date -u --iso-8601=seconds
systemctl is-enabled lnmesh-mesh lnmesh-mesh-health.timer
batctl meshif bat0 neighbors
ip -br addr
journalctl -b -u lnmesh-mesh --no-pager
