export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
set -euo pipefail
hostname
date -u --iso-8601=seconds
source /etc/lnmesh/mesh.env
for peer in 10.10.0.1 10.10.0.2 10.10.0.3; do
  test "$peer" = "$MESH_IP" && continue
  ip route get "$peer"
  ping -n -q -I bat0 -c 20 -i 0.1 -W 2 "$peer"
  ping -n -q -I bat0 -c 3 -i 0.2 -W 2 -M do -s 1472 "$peer"
done
batctl meshif bat0 neighbors
batctl meshif bat0 originators
systemctl is-active lnmesh-mesh lnmesh-mesh-health.timer lnd chrony
systemctl is-enabled lnmesh-mesh lnmesh-mesh-health.timer
ip -br addr
uname -r
