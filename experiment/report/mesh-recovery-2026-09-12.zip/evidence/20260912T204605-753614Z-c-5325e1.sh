export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
set -euo pipefail
boot=$(cat /proc/sys/kernel/random/boot_id)
test "$boot" != 56a790d7-f6ba-460d-929f-9f99dfcccfac
test "$(cat /sys/class/net/bat0/address)" = a2:8a:1f:07:7e:04
systemctl is-active --quiet lnmesh-mesh
systemctl is-active --quiet lnmesh-mesh-health.timer
source /etc/lnmesh/mesh.env
for peer in 10.10.0.1 10.10.0.2 10.10.0.3; do
  test "$peer" = "$MESH_IP" && continue
  ping -n -I bat0 -c 1 -W 1 "$peer" >/dev/null
done
printf '%s\n' "$boot"
