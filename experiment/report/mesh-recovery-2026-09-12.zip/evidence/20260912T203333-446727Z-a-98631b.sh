export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
python3 - <<'PY'
import concurrent.futures,ipaddress,socket,subprocess
network=ipaddress.ip_network('10.17.4.0/23')
def probe(address):
    with socket.socket() as s:
        s.settimeout(0.8)
        s.connect_ex((str(address),22))
with concurrent.futures.ThreadPoolExecutor(max_workers=32) as pool:
    list(pool.map(probe,network.hosts()))
rows=subprocess.check_output(['ip','neigh','show','dev','eth0'],text=True)
matches=[r for r in rows.splitlines() if any(mac in r.lower() for mac in ['2c:cf:67:3c:09:e5','2c:cf:67:3c:07:ab'])]
print('Known leaf Ethernet MAC matches:')
print('\n'.join(matches) if matches else 'No responding addresses for either leaf MAC.')
PY
