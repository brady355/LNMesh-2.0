"""Reboot each Pi once; verify a new boot, stable MAC, and both mesh paths."""
import datetime as dt
import json
import os
from pathlib import Path
import shlex
import sys
import time

BASE = Path.cwd()
sys.path.insert(0, str(BASE / "experiment"))
import runner

runner.EVIDENCE = Path(__file__).resolve().parent
r = runner.Runner("lan", verbose=False)
assert r.password, "Supply the sudo password through the process environment."
records = []
for host in "bca":
    before = r.run(host, "cat /proc/sys/kernel/random/boot_id\ncat /sys/class/net/bat0/address",
                   root=False, label="reboot-before-state", timeout=15)["stdout"].splitlines()
    old_boot, old_mac = before
    record = {"host": runner.HOSTS[host], "before_boot_id": old_boot,
              "mesh_mac": old_mac, "started_utc": runner.utc(), "poll_interval_seconds": 5}
    start = time.monotonic()
    r.run(host, "systemd-run --unit=lnmesh-verify-reboot --on-active=3s /usr/sbin/reboot",
          label="schedule-recovery-verification-reboot", timeout=15)
    print(f"{runner.HOSTS[host]}: reboot scheduled", flush=True)
    check = """set -euo pipefail
boot=$(cat /proc/sys/kernel/random/boot_id)
test "$boot" != OLD_BOOT
test "$(cat /sys/class/net/bat0/address)" = OLD_MAC
systemctl is-active --quiet lnmesh-mesh
systemctl is-active --quiet lnmesh-mesh-health.timer
source /etc/lnmesh/mesh.env
for peer in 10.10.0.1 10.10.0.2 10.10.0.3; do
  test "$peer" = "$MESH_IP" && continue
  ping -n -I bat0 -c 1 -W 1 "$peer" >/dev/null
done
printf '%s\\n' "$boot"
""".replace("OLD_BOOT", shlex.quote(old_boot)).replace("OLD_MAC", shlex.quote(old_mac))
    while time.monotonic() - start < 180:
        time.sleep(5)
        result = r.run(host, check, label="reboot-readiness-probe", timeout=16, check=False)
        if result["returncode"] == 0:
            record.update(success=True, after_boot_id=result["stdout"].strip(),
                          finished_utc=runner.utc(),
                          observed_recovery_seconds=round(time.monotonic() - start, 3))
            break
    else:
        record.update(success=False, finished_utc=runner.utc(),
                      elapsed_seconds=round(time.monotonic() - start, 3))
    records.append(record)
    (runner.EVIDENCE / "reboot-results.json").write_text(json.dumps(records, indent=2) + "\n")
    print(json.dumps(record), flush=True)
    if not record["success"]:
        raise SystemExit(1)
    r.run(host, """date -u --iso-8601=seconds
systemctl is-enabled lnmesh-mesh lnmesh-mesh-health.timer
batctl meshif bat0 neighbors
ip -br addr
journalctl -b -u lnmesh-mesh --no-pager
""", label="verified-reboot-state", timeout=20)
