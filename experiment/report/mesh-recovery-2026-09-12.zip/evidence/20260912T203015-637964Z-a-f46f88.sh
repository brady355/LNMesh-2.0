export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
date -u --iso-8601=seconds
hostname
ip -br addr
iw dev
batctl meshif bat0 neighbors
batctl meshif bat0 originators
systemctl --no-pager --full status lnmesh-mesh
cat /etc/lnmesh/mesh.env
