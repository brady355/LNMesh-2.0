export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
hostname
printf "SSH_CONNECTION=%s\n" "$SSH_CONNECTION"