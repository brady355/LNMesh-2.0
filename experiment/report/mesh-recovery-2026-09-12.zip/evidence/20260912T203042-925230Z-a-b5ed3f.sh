export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
date -u --iso-8601=seconds
cat /usr/local/sbin/lnmesh-mesh
systemctl is-enabled lnmesh-mesh
nmcli device status
rfkill list
ip route
command -v tcpdump
command -v arping
command -v avahi-browse
iw dev wlan0 scan dump | grep -E '^(BSS|[[:space:]]+(SSID:|freq:|capability:))' || true
