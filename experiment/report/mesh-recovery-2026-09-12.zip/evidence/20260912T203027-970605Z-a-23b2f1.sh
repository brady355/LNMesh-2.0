export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
date -u --iso-8601=seconds
cat /usr/local/sbin/lnmesh-mesh.sh
systemctl cat lnmesh-mesh
batctl meshif bat0 interface
iw dev wlan0 link
iw dev wlan0 station dump
ip neigh
journalctl -k -n 80 --no-pager
