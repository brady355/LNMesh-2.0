export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
set -euo pipefail
python3 - <<'PY'
import datetime,json,pathlib,socket,subprocess,time
host=socket.gethostname()
ips={'pi1gateway':'10.10.0.1','pi2':'10.10.0.2','pi3':'10.10.0.3'}
faults={'pi1gateway':['systemctl','stop','lnmesh-mesh'], 'pi2':['iw','dev','wlan0','ibss','leave'], 'pi3':['ip','link','set','bat0','down']}
def run(args,timeout=8):
    return subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
invocation=run(['systemctl','show','lnmesh-mesh','-p','InvocationID','--value']).stdout.strip()
record={'host':host,'fault':faults[host],'started_utc':utc(),'before_invocation':invocation,'poll_seconds':3}
started=time.monotonic()
run(faults[host]).check_returncode()
record['fault_injected_utc']=utc()
pathlib.Path('/run/lnmesh-recovery-test.json').write_text(json.dumps(record))
while time.monotonic()-started<285:
    current=run(['systemctl','show','lnmesh-mesh','-p','InvocationID','--value']).stdout.strip()
    active=run(['systemctl','is-active','--quiet','lnmesh-mesh']).returncode==0
    if active and current and current!=invocation:
        if 'service_restored_seconds' not in record:
            record['service_restored_seconds']=round(time.monotonic()-started,3)
            record['after_invocation']=current
        peers=[ip for name,ip in ips.items() if name!=host]
        reachable=[run(['ping','-n','-I','bat0','-c','1','-W','1',ip],timeout=3).returncode==0 for ip in peers]
        if all(reachable):
            record.update(success=True,finished_utc=utc(),all_peers_reachable_seconds=round(time.monotonic()-started,3))
            pathlib.Path('/run/lnmesh-recovery-test.json').write_text(json.dumps(record))
            print(json.dumps(record,indent=2),flush=True)
            break
    time.sleep(3)
else:
    record.update(success=False,finished_utc=utc(),elapsed_seconds=round(time.monotonic()-started,3))
    pathlib.Path('/run/lnmesh-recovery-test.json').write_text(json.dumps(record))
    print(json.dumps(record,indent=2),flush=True)
    raise SystemExit(1)
PY
batctl meshif bat0 neighbors
journalctl -u lnmesh-mesh-health -u lnmesh-mesh --since '6 minutes ago' --no-pager
