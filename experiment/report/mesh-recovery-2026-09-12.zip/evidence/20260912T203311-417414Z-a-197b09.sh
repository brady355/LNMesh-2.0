export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
date -u --iso-8601=seconds
iw dev wlan0 link
batctl meshif bat0 neighbors
batctl meshif bat0 originators
systemctl is-enabled lnmesh-mesh
command -v arp-scan || true
command -v nmap || true
ip neigh
