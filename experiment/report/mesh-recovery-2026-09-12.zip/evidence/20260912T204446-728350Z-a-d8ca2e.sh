export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
date -u --iso-8601=seconds
hostname
sha256sum /usr/local/sbin/lnmesh-mesh /usr/local/sbin/lnmesh-mesh-health /etc/systemd/system/lnmesh-mesh.service.d/recovery.conf /etc/systemd/system/lnmesh-mesh-health.service /etc/systemd/system/lnmesh-mesh-health.timer
systemctl is-enabled lnmesh-mesh lnmesh-mesh-health.timer
