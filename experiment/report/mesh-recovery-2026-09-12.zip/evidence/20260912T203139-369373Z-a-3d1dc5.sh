export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
date -u --iso-8601=seconds
ping -6 -I wlan0 -c 2 -W 2 fe80::2ecf:67ff:fe3c:9e6 &
ping -6 -I wlan0 -c 2 -W 2 fe80::2ecf:67ff:fe3c:7ac &
wait
timeout 10 tcpdump -n -e -i wlan0 -c 12 'ether proto 0x4305' || true
lsmod | grep -E 'brcm|cfg80211|batman'
journalctl -k --since '5 minutes ago' --no-pager
