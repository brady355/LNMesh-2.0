export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
systemd-run --unit=lnmesh-verify-reboot --on-active=3s /usr/sbin/reboot