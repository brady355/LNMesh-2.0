export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
set -euo pipefail
date -u --iso-8601=seconds
systemctl stop lnmesh-mesh
ip link set wlan0 down
modprobe -r brcmfmac_cyw brcmfmac
modprobe brcmfmac
for attempt in $(seq 1 20); do test -e /sys/class/net/wlan0 && break; sleep 1; done
systemctl start lnmesh-mesh
for attempt in $(seq 1 15); do
  if ping -I bat0 -c 1 -W 1 10.10.0.2 >/dev/null 2>&1 && ping -I bat0 -c 1 -W 1 10.10.0.3 >/dev/null 2>&1; then break; fi
  sleep 1
done
iw dev wlan0 link
batctl meshif bat0 neighbors
batctl meshif bat0 originators
