export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
set -euo pipefail
date -u --iso-8601=seconds
systemctl restart lnmesh-mesh
for attempt in $(seq 1 10); do
  if ping -I bat0 -c 1 -W 1 10.10.0.1; then break; fi
  sleep 1
done
iw dev wlan0 link
batctl meshif bat0 neighbors
batctl meshif bat0 originators
