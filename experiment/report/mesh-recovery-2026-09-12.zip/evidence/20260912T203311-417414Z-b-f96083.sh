export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
hostname
ip -br addr
batctl meshif bat0 neighbors
systemctl is-enabled lnmesh-mesh