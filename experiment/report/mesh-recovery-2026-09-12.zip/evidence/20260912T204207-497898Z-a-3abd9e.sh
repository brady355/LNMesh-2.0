export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
date -u --iso-8601=seconds
hostname
systemctl is-active lnmesh-mesh lnmesh-mesh-health.timer
cat /run/lnmesh-mesh-health.failures
journalctl -u lnmesh-mesh-health --since '3 minutes ago' --no-pager -n 9
