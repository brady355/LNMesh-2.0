export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
set -euo pipefail
boot=$(cat /proc/sys/kernel/random/boot_id)
test "$boot" != 7e65a506-7c05-4b98-9d0c-eead5e74d996
test "$(cat /sys/class/net/bat0/address)" = 82:d6:e3:11:03:bf
systemctl is-active --quiet lnmesh-mesh
systemctl is-active --quiet lnmesh-mesh-health.timer
source /etc/lnmesh/mesh.env
for peer in 10.10.0.1 10.10.0.2 10.10.0.3; do
  test "$peer" = "$MESH_IP" && continue
  ping -n -I bat0 -c 1 -W 1 "$peer" >/dev/null
done
printf '%s\n' "$boot"
