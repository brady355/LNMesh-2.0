export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
date -u --iso-8601=seconds
iw dev wlan0 link
iw dev wlan0 station dump
batctl meshif bat0 neighbors
(timeout 12 iw dev wlan0 scan freq 2412) | grep -E '^(BSS|[[:space:]]+(SSID:|freq:|capability:|signal:))' || true
journalctl -u lnmesh-mesh --since '10 minutes ago' --no-pager
