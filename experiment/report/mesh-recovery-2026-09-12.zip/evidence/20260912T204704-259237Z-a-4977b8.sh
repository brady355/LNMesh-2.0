export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
set -euo pipefail
boot=$(cat /proc/sys/kernel/random/boot_id)
test "$boot" != f9d294de-d654-45d7-802e-1fa13e0f7fb2
test "$(cat /sys/class/net/bat0/address)" = 42:dd:83:e7:7e:8b
systemctl is-active --quiet lnmesh-mesh
systemctl is-active --quiet lnmesh-mesh-health.timer
source /etc/lnmesh/mesh.env
for peer in 10.10.0.1 10.10.0.2 10.10.0.3; do
  test "$peer" = "$MESH_IP" && continue
  ping -n -I bat0 -c 1 -W 1 "$peer" >/dev/null
done
printf '%s\n' "$boot"
